import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import data.TestData;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Grinder {
    public static void main(String[] args) throws IOException {
        List<TestData> list = makeListFromExcel(args[0], args[1]);
        makeJsonFiles(list);
    }

    private static List makeListFromExcel(String excelPath, String sheetNum) {
        List<TestData> list = new ArrayList<>();
        try {
            FileInputStream file = new FileInputStream(new File(excelPath));

            //Create Workbook instance holding reference to .xlsx file
            XSSFWorkbook workbook = new XSSFWorkbook(file);

            //Get first/desired sheet from the workbook
            XSSFSheet sheet = workbook.getSheetAt(Integer.parseInt(sheetNum));

            //Iterate through each rows one by one
            Iterator<Row> rowIterator = sheet.iterator();
            rowIterator.next();
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                //For each row, iterate through all the columns
                Iterator<Cell> cellIterator = row.cellIterator();
                TestData testData = new TestData();
                int seq = 0;
                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();
                    //Check the cell type and format accordingly
                    if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
                        System.out.print(cell.getStringCellValue() + "\t");
                        if (seq == 0) {
                            testData.setBankName(cell.getStringCellValue());
                            seq++;
                        } else if (seq == 1) {
                            testData.setApiCode(cell.getStringCellValue());
                            seq++;
                        } else if (seq == 2) {
                            testData.setBankSeq(cell.getStringCellValue());
                            seq++;
                        } else if (seq == 3) {
                            testData.setResponse(cell.getStringCellValue());
                        } else System.out.println("Error occurred while reading excel row");
                    }

                }
                list.add(testData);
                System.out.println("");
            }
            file.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    private static void makeJsonFiles(List<TestData> list) throws IOException {
        System.out.println("===== started json file creation =====");
        for (TestData testData : list) {
            // Naming file
            System.out.println("stored content \t" + testData.toString());
            StringBuilder sb = new StringBuilder();
            sb.append("테스트");
            sb.append("-");
            sb.append(testData.getBankName());
            sb.append(testData.getBankSeq());
            sb.append("-");
            sb.append("은행");
            sb.append(testData.getApiCode());
            sb.append(".json");

            // Write file using gson
            try (Writer writer = new FileWriter(sb.toString())) {
                Gson gson = new GsonBuilder()
                        .disableHtmlEscaping()
                        .create();

                String response = testData.getResponse().replaceAll("\\\\", "'");
                response = response.replaceAll("\n", "");
                response = response.replaceAll("\" \\{", "{");
                gson.toJson(response, writer);
            }

        }

        System.out.println("===== finished json creation successfully =====");
    }
}
